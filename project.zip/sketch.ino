#include <LiquidCrystal.h>

// LCD pins: RS, E, D4, D5, D6, D7
LiquidCrystal lcd(12, 11, 5, 4, 3, 2);

int tempPin = A0;
int voltagePin = A1;
int buzzer = 8;
int motorLED = 9;

void setup() {
  lcd.begin(16, 2);

  pinMode(buzzer, OUTPUT);
  pinMode(motorLED, OUTPUT);

  Serial.begin(9600);

  lcd.print("AI Maintenance");
  delay(2000);
  lcd.clear();
}

void loop() {
  int tempValue = analogRead(tempPin);
  int voltageValue = analogRead(voltagePin);

  // TMP36 temperature calculation
  float voltage = tempValue * (5.0 / 1023.0);
  float temperature = (voltage - 0.5) * 100.0;

  // Potentiometer voltage simulation
  float batteryVoltage = voltageValue * (24.0 / 1023.0);

  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Temp:");
  lcd.print(temperature);
  lcd.print("C");

  lcd.setCursor(0, 1);
  lcd.print("Batt:");
  lcd.print(batteryVoltage);
  lcd.print("V");

  Serial.print("Temperature: ");
  Serial.print(temperature);
  Serial.print(" C | Battery: ");
  Serial.print(batteryVoltage);
  Serial.println(" V");

  if (temperature > 70 || batteryVoltage < 18) {
    digitalWrite(buzzer, HIGH);
    digitalWrite(motorLED, LOW);

    delay(1000);
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("WARNING!");
    lcd.setCursor(0, 1);
    lcd.print("Maintenance");
  } 
  else {
    digitalWrite(buzzer, LOW);
    digitalWrite(motorLED, HIGH);
  }

  delay(1000);
}